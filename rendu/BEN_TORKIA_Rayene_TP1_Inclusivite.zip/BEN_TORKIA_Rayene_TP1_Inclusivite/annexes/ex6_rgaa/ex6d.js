const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ locale: 'fr-FR' })).newPage();
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3500);
  const links = page.getByRole('link', { name: /accessibilit/i });
  const n = await links.count();
  for (let i = 0; i < n; i++) console.log('FT lien:', JSON.stringify(await links.nth(i).innerText()), await links.nth(i).getAttribute('href'));
  if (!n) console.log('FT: aucun lien contenant « accessibilité » (y compris shadow DOM)');
  await browser.close();
})();
