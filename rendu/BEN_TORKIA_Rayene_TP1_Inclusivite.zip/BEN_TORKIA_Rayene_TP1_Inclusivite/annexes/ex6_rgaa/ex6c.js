const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ locale: 'fr-FR' })).newPage();
  for (const u of ['https://www.service-public.gouv.fr/', 'https://www.francetravail.fr/accueil/', 'https://www.franceconnect.gouv.fr/']) {
    await page.goto(u, { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3000);
    const t = await page.evaluate(() => [...document.querySelectorAll('a')].map(a => a.innerText.trim().replace(/\s+/g, ' ')).filter(x => /accessibilit/i.test(x)).slice(0, 3));
    console.log(u, JSON.stringify(t));
  }
  await browser.close();
})();
