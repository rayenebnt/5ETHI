// Exercise 6 - RGAA theme 3 (Couleurs) on a sample of France Travail pages, plus a full axe pass
// on the three home pages for comparison. Criteria: 3.1 (information not by colour alone, partly
// automated through link-in-text-block), 3.2 (text contrast) and 3.3 (contrast of UI components).
const { chromium } = require('playwright');
const fs = require('fs');
const AXE = __dirname + '/axe/node_modules/axe-core/axe.min.js';
const OUT = __dirname + '/ex6';
fs.mkdirSync(OUT, { recursive: true });

const pages = [
  ['FT_accueil', 'https://www.francetravail.fr/accueil/'],
  ['FT_faq', 'https://www.francetravail.fr/faq/candidat.html'],
  ['FT_droits', 'https://www.francetravail.fr/candidat/mes-droits-aux-aides-et-allocati.html'],
  ['SP_accueil', 'https://www.service-public.gouv.fr/'],
  ['FC_accueil', 'https://www.franceconnect.gouv.fr/'],
];

// Relative luminance / contrast (WCAG formula) for the custom 3.3 checks.
const contrastFn = `(() => {
  const lum = c => { const [r,g,b] = c.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126*r + 0.7152*g + 0.0722*b; };
  const parse = s => { const m = s.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(/[ ,\\/]+/).filter(Boolean).map(Number); return { rgb: p.slice(0,3), a: p.length > 3 ? p[3] : 1 }; };
  const bgOf = el => { for (let e = el; e; e = e.parentElement) { const c = parse(getComputedStyle(e).backgroundColor); if (c && c.a > 0.5) return c.rgb; } return [255,255,255]; };
  const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
  return { parse, bgOf, ratio };
})()`;

(async () => {
  const browser = await chromium.launch();
  const summary = {};
  for (const [name, url] of pages) {
    const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'fr-FR' });
    const page = await ctx.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(3500);
    const btn = page.getByRole('button', { name: /Continuer sans accepter/i }).first();
    if (await btn.count()) { await btn.click().catch(() => {}); await page.waitForTimeout(800); }
    await page.addScriptTag({ path: AXE });
    const full = await page.evaluate(async () => {
      const r = await axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] }, resultTypes: ['violations', 'incomplete'] });
      const pick = list => list.map(v => ({ id: v.id, impact: v.impact, n: v.nodes.length, help: v.help,
        nodes: v.nodes.slice(0, 6).map(n => ({ target: n.target.join(' '), html: n.html.slice(0, 160), msg: (n.any[0] || n.all[0] || n.none[0] || {}).message, data: (n.any[0] || {}).data })) }));
      return { violations: pick(r.violations), incomplete: pick(r.incomplete) };
    });
    const contrast = await page.evaluate(async () => {
      const r = await axe.run(document, { runOnly: { type: 'rule', values: ['color-contrast', 'link-in-text-block'] }, resultTypes: ['passes', 'violations', 'incomplete'] });
      const count = id => ({ pass: (r.passes.find(x => x.id === id) || { nodes: [] }).nodes.length, fail: (r.violations.find(x => x.id === id) || { nodes: [] }).nodes.length, incomplete: (r.incomplete.find(x => x.id === id) || { nodes: [] }).nodes.length });
      const fails = (r.violations.find(x => x.id === 'color-contrast') || { nodes: [] }).nodes.map(n => ({ target: n.target.join(' '), text: n.html.replace(/<[^>]+>/g, '').trim().slice(0, 60), ...((n.any[0] || {}).data || {}) }));
      return { cc: count('color-contrast'), lit: count('link-in-text-block'), fails };
    });
    // 3.3: borders of form fields / buttons and the focus indicator, against what is behind them
    const ui = await page.evaluate(src => {
      const C = eval(src);
      const out = [];
      const fields = [...document.querySelectorAll('input:not([type=hidden]), select, textarea')].filter(e => e.offsetParent);
      for (const f of fields.slice(0, 8)) {
        const s = getComputedStyle(f); const bg = C.bgOf(f.parentElement);
        const sides = ['Top', 'Right', 'Bottom', 'Left'].map(k => ({ w: parseFloat(s['border' + k + 'Width']), c: C.parse(s['border' + k + 'Color']) })).filter(x => x.w > 0 && x.c && x.c.a > 0);
        const best = sides.length ? Math.max(...sides.map(x => C.ratio(x.c.rgb, bg))) : null;
        const fill = C.parse(s.backgroundColor); const fillRatio = fill && fill.a > 0.5 ? C.ratio(fill.rgb, bg) : null;
        out.push({ kind: 'champ', id: f.id || f.name, border: best && +best.toFixed(2), fillVsBg: fillRatio && +fillRatio.toFixed(2), sides: sides.map(x => x.w + 'px').join('/') });
      }
      return out;
    }, contrastFn);
    summary[name] = { url, contrast, ui, violations: full.violations.map(v => `${v.id} (${v.impact}) x${v.n}`), incomplete: full.incomplete.map(v => `${v.id} x${v.n}`) };
    fs.writeFileSync(`${OUT}/${name}_axe.json`, JSON.stringify(full, null, 1));
    // screenshots of the first contrast failures, outlined in red
    let k = 0;
    for (const f of contrast.fails.slice(0, 4)) {
      const loc = page.locator(f.target).first();
      try { await loc.scrollIntoViewIfNeeded({ timeout: 3000 }); await loc.evaluate(e => { e.style.outline = '3px solid red'; e.style.outlineOffset = '2px'; });
        const b = await loc.boundingBox(); if (b) await page.screenshot({ path: `${OUT}/${name}_contraste_${++k}.png`, clip: { x: Math.max(0, b.x - 40), y: Math.max(0, b.y - 30), width: Math.min(700, b.width + 80), height: Math.min(300, b.height + 60) } });
      } catch (e) { /* element not visible */ }
    }
    console.log(`\n===== ${name}  ${url}`);
    console.log(' contrast:', JSON.stringify(contrast.cc), 'link-in-text-block:', JSON.stringify(contrast.lit));
    for (const f of contrast.fails.slice(0, 10)) console.log(`  FAIL ${f.contrastRatio}:1 (attendu ${f.expectedContrastRatio}) fg=${f.fgColor} bg=${f.bgColor} ${f.fontSize} ${f.fontWeight} "${f.text}"`);
    console.log(' champs (3.3):', JSON.stringify(ui));
    console.log(' axe violations:', summary[name].violations.join(', ') || 'aucune');
    console.log(' axe à vérifier:', summary[name].incomplete.join(', ') || 'rien');
    await ctx.close();
  }
  fs.writeFileSync(`${OUT}/summary.json`, JSON.stringify(summary, null, 1));
  await browser.close();
})();
