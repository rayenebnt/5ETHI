const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'fr-FR' })).newPage();
  // field borders on the home page (criterion 3.3)
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3500);
  await page.getByRole('button', { name: /Continuer sans accepter/i }).first().click().catch(() => {}); await page.waitForTimeout(800);
  const box = await page.locator('#form-input-recherche-offre').boundingBox();
  const st = await page.locator('#form-input-recherche-offre').evaluate(e => { const s = getComputedStyle(e); return { border: s.border, shadow: s.boxShadow, outline: s.outline, parentBorder: getComputedStyle(e.parentElement).border, bg: s.backgroundColor }; });
  await page.screenshot({ path: __dirname + '/ex6/FT_champ.png', clip: { x: box.x - 20, y: box.y - 40, width: box.width + 40, height: box.height + 60 } });
  console.log('FT champ bbox', box, st);
  // FAQ page: how is the selected theme shown?
  await page.goto('https://www.francetravail.fr/faq/candidat.html', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3500);
  await page.getByRole('button', { name: /Continuer sans accepter/i }).first().click().catch(() => {}); await page.waitForTimeout(800);
  const faq = await page.evaluate(() => {
    const el = [...document.querySelectorAll('*')].find(e => e.children.length === 0 && /Questions Fréquentes/.test(e.textContent));
    if (!el) return null;
    const chain = [];
    for (let e = el; e && chain.length < 6; e = e.parentElement) chain.push(`${e.tagName.toLowerCase()}${e.className ? '.' + String(e.className).split(' ').slice(0, 2).join('.') : ''} aria-current=${e.getAttribute('aria-current')} aria-selected=${e.getAttribute('aria-selected')} role=${e.getAttribute('role')}`);
    const r = el.getBoundingClientRect();
    return { chain, box: { x: r.x, y: r.y + window.scrollY, w: r.width, h: r.height } };
  });
  console.log('FAQ "Questions Fréquentes":', JSON.stringify(faq, null, 1));
  if (faq) { await page.evaluate(y => window.scrollTo(0, Math.max(0, y - 200)), faq.box.y); await page.waitForTimeout(400); await page.screenshot({ path: __dirname + '/ex6/FT_faq_zone.png' }); }
  // incomplete contrast items: why axe could not decide
  for (const n of ['FT_accueil', 'FT_faq', 'FT_droits']) {
    const j = JSON.parse(fs.readFileSync(`${__dirname}/ex6/${n}_axe.json`));
    const cc = j.incomplete.find(v => v.id === 'color-contrast');
    if (cc) console.log(n, 'incomplete reasons:', [...new Set(cc.nodes.map(x => (x.msg || '').slice(0, 90)))]);
  }
  await browser.close();
})();
