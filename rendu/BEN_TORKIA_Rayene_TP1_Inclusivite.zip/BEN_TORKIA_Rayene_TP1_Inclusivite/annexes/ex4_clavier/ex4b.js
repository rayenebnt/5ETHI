// Follow-up keyboard checks: focus visibility on suspicious stops, France Travail search forms,
// FranceConnect "Aide" link. Accessible names are read from the browser's accessibility tree.
const { chromium } = require('playwright');
const OUT = __dirname + '/ex4';
const aria = async (page) => (await page.locator(':focus').first().ariaSnapshot().catch(() => '(?)')).split('\n')[0];
const tabTo = async (page, n) => { for (let i = 0; i < n; i++) { await page.keyboard.press('Tab'); await page.waitForTimeout(120); } };

(async () => {
  const browser = await chromium.launch();
  const mk = async () => (await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'fr-FR' })).newPage();

  // service-public: logo link (Tab 5) and the "Je déménage" card (Tab 17)
  let page = await mk();
  await page.goto('https://www.service-public.gouv.fr/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
  await tabTo(page, 5); console.log('SP tab5', await aria(page)); await page.screenshot({ path: `${OUT}/SP_focus_logo.png` });
  await tabTo(page, 12); console.log('SP tab17', await aria(page)); await page.screenshot({ path: `${OUT}/SP_focus_jedemenage.png` });
  console.log('SP tab17 styles', await page.evaluate(() => { const e = document.activeElement; const s = getComputedStyle(e); const p = e.closest('div'); return { outline: s.outline, offset: s.outlineOffset, before: getComputedStyle(e, '::before').outline, parentOutline: p && getComputedStyle(p).outline }; }));
  await page.context().close();

  // France Travail
  page = await mk();
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3500);
  await page.keyboard.press('Tab'); await page.keyboard.press('Enter'); await page.waitForTimeout(1000);
  console.log('FT after cookies, activeElement =', await page.evaluate(() => document.activeElement === document.body ? 'body' : document.activeElement.tagName));
  await page.keyboard.press('Tab'); console.log('FT first Tab after cookies ->', await aria(page));
  // header search dropdown
  let n = 0; do { await page.keyboard.press('Tab'); n++; } while (!(await page.evaluate(() => document.activeElement.id === 'dropdown-search-btn')) && n < 20);
  console.log(`FT bouton Rechercher atteint (Tab n°${n + 1} depuis la fermeture des cookies):`, await aria(page));
  await page.keyboard.press('Enter'); await page.waitForTimeout(800);
  console.log('FT after Enter expanded =', await page.evaluate(() => document.getElementById('dropdown-search-btn').getAttribute('aria-expanded')));
  await page.keyboard.press('Tab'); await page.waitForTimeout(300);
  console.log('FT next Tab ->', await aria(page), '| id =', await page.evaluate(() => document.activeElement.id));
  console.log('FT #search-input attrs', await page.evaluate(() => { const i = document.getElementById('search-input'); return i ? { placeholder: i.placeholder, ariaLabel: i.getAttribute('aria-label'), labelledby: i.getAttribute('aria-labelledby'), title: i.title, labels: i.labels ? i.labels.length : 0 } : null; }));
  console.log('FT #search-input aria', await page.locator('#search-input').ariaSnapshot().catch(e => 'n/a'));
  await page.screenshot({ path: `${OUT}/FT_recherche_ouverte.png` });
  if (await page.evaluate(() => document.activeElement.id === 'search-input')) {
    await page.keyboard.type('attestation employeur', { delay: 40 });
    await Promise.all([page.waitForNavigation({ timeout: 30000 }).catch(() => {}), page.keyboard.press('Enter')]);
    await page.waitForTimeout(2500);
    console.log('FT recherche envoyée ->', page.url(), '|', await page.title());
  }
  // offers search with autocomplete
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3000);
  for (const id of ['form-input-recherche-offre', 'autocomplete-lieu']) console.log(`FT #${id}`, await page.locator('#' + id).ariaSnapshot().catch(() => 'n/a'), await page.evaluate(i => { const e = document.getElementById(i); return { placeholder: e.placeholder, labels: e.labels ? [...e.labels].map(l => l.innerText.trim().replace(/\s+/g, ' ')) : [] }; }, id));
  n = 0; do { await page.keyboard.press('Tab'); n++; } while (!(await page.evaluate(() => document.activeElement.id === 'form-input-recherche-offre')) && n < 25);
  console.log(`FT champ métier atteint en ${n} Tab`);
  await page.keyboard.type('infirmier', { delay: 50 }); await page.waitForTimeout(1200);
  await page.keyboard.press('Tab'); await page.keyboard.type('Lyo', { delay: 80 }); await page.waitForTimeout(2000);
  const sugg = await page.evaluate(() => [...document.querySelectorAll('[role=option]')].slice(0, 5).map(o => o.innerText.trim()));
  console.log('FT suggestions lieu:', sugg);
  await page.keyboard.press('ArrowDown'); await page.waitForTimeout(500);
  console.log('FT après flèche bas: activedescendant=', await page.evaluate(() => document.activeElement.getAttribute('aria-activedescendant')), 'expanded=', await page.evaluate(() => document.activeElement.getAttribute('aria-expanded')));
  await page.screenshot({ path: `${OUT}/FT_autocomplete.png` });
  await page.keyboard.press('Enter'); await page.waitForTimeout(800);
  console.log('FT lieu choisi =', await page.evaluate(() => document.getElementById('autocomplete-lieu').value));
  let popup = null; page.context().on('page', p => { popup = p; });
  n = 0; do { await page.keyboard.press('Tab'); n++; } while (!/Rechercher les offres/.test(await aria(page)) && n < 6);
  console.log(`FT bouton de recherche atteint en ${n} Tab:`, await aria(page));
  await page.keyboard.press('Enter'); await page.waitForTimeout(6000);
  if (popup) { await popup.waitForLoadState('domcontentloaded').catch(() => {}); console.log('FT nouvelle fenêtre ouverte ->', popup.url(), '|', await popup.title()); await popup.screenshot({ path: `${OUT}/FT_offres.png` }); }
  else console.log('FT pas de nouvelle fenêtre; url =', page.url());
  await page.context().close();

  // FranceConnect: logo focus, the empty-text footer link, and the Aide link
  page = await mk();
  await page.goto('https://www.franceconnect.gouv.fr/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
  await tabTo(page, 4); console.log('FC tab4', await aria(page)); await page.screenshot({ path: `${OUT}/FC_focus_logo.png` });
  console.log('FC lien Aide', await page.evaluate(() => { const a = [...document.querySelectorAll('a')].find(x => x.innerText.trim() === 'Aide'); return a && { href: a.href, target: a.target, title: a.title, aria: a.getAttribute('aria-label') }; }));
  console.log('FC liens sans texte visible', await page.evaluate(() => [...document.querySelectorAll('a[href]')].filter(a => !a.innerText.trim()).slice(0, 6).map(a => ({ href: a.href.slice(0, 60), aria: a.getAttribute('aria-label'), title: a.title, img: a.querySelector('img') ? a.querySelector('img').alt : null, html: a.outerHTML.slice(0, 160) }))));
  await page.context().close();
  await browser.close();
})();
