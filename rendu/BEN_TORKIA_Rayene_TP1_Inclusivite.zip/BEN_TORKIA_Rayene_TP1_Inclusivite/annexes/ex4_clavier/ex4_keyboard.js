// Exercise 4 - keyboard-only test, driven with real key presses (Tab, Shift+Tab, Enter, Space, arrows).
// For every tab stop we keep the element, its accessible name, and two crops of the same area:
// focused ("on") and after focus has moved on ("off"), to measure whether focus is visible.
const { chromium } = require('playwright');
const fs = require('fs');
const OUT = __dirname + '/ex4';
fs.mkdirSync(OUT + '/crops', { recursive: true });

const results = {};
const log = (site, msg) => { console.log(`[${site}] ${msg}`); const r = (results[site] = results[site] || {}); (r.log = r.log || []).push(msg); };

async function active(page) {
  return page.evaluate(() => {
    let e = document.activeElement;
    while (e && e.shadowRoot && e.shadowRoot.activeElement) e = e.shadowRoot.activeElement;
    if (!e || e === document.body) return { tag: 'body', name: '', box: null };
    const r = e.getBoundingClientRect();
    const name = (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.title || e.getAttribute('alt') || '').trim().replace(/\s+/g, ' ').slice(0, 70);
    e.setAttribute('data-kbd-probe', '1');
    return {
      tag: e.tagName.toLowerCase() + (e.id ? '#' + e.id : ''), role: e.getAttribute('role') || '', name,
      expanded: e.getAttribute('aria-expanded'), href: e.getAttribute('href') || '',
      box: r.width && r.height ? { x: r.x, y: r.y, w: r.width, h: r.height } : null, sy: window.scrollY,
    };
  });
}

async function crop(page, box, file) {
  if (!box) return false;
  const vp = page.viewportSize();
  const m = 8;
  const x = Math.max(0, box.x - m), y = Math.max(0, box.y - m);
  const w = Math.min(vp.width - x, box.w + 2 * m), h = Math.min(vp.height - y, box.h + 2 * m);
  if (w < 4 || h < 4 || y > vp.height || x > vp.width) return false;
  await page.screenshot({ path: file, clip: { x, y, width: w, height: h } });
  return true;
}

// Tab through the page; returns the list of stops (with on/off crops for visibility analysis).
async function tabWalk(page, site, max, stopRe) {
  const stops = [];
  for (let i = 1; i <= max; i++) {
    await page.keyboard.press('Tab');
    await page.waitForTimeout(250);
    const a = await active(page);
    a.i = i;
    a.on = await crop(page, a.box, `${OUT}/crops/${site}_${i}_on.png`) ? `${site}_${i}_on.png` : null;
    // remove the marker from the previous element, re-measure it now that it lost focus
    if (stops.length) {
      const prev = stops[stops.length - 1];
      const box = await page.evaluate(() => {
        const e = document.querySelector('[data-kbd-probe="1"]:not(:focus)') || null;
        return null;
      });
      void box;
    }
    stops.push(a);
    if (stopRe && stopRe.test(a.name + ' ' + a.tag)) break;
  }
  return stops;
}

// Visibility: for each stop, focus it via keyboard order again is costly; instead we re-crop the same
// rectangle with focus moved away (blur), which shows the element in its normal state.
async function offCrops(page, site, stops) {
  for (const s of stops) {
    if (!s.on || !s.box) continue;
    await page.evaluate(y => window.scrollTo(0, y), s.sy || 0);
    await page.waitForTimeout(120);
    s.off = await crop(page, s.box, `${OUT}/crops/${site}_${s.i}_off.png`) ? `${site}_${s.i}_off.png` : null;
  }
}

async function newPage(browser) {
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'fr-FR' });
  return ctx.newPage();
}

(async () => {
  const browser = await chromium.launch();

  // ---------- service-public ----------
  {
    const site = 'SP';
    let page = await newPage(browser);
    await page.goto('https://www.service-public.gouv.fr/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3000);
    await page.evaluate(() => window.scrollTo(0, 0));
    const stops = await tabWalk(page, site, 30);
    // focus away without scrolling: click on an empty spot is mouse - instead blur programmatically for the "off" picture
    await page.evaluate(() => { document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0); });
    await page.waitForTimeout(300);
    await offCrops(page, site, stops);
    results[site] = { ...(results[site] || {}), stops };
    log(site, 'first stops: ' + stops.slice(0, 12).map(s => `${s.i}:${s.tag}"${s.name}"`).join(' | '));

    // T-menu: reach "Fiches pratiques par thème", open with Enter, move inside with Tab, close with Escape
    await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
    let n = 0, a;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/par thème/i.test(a.name) && n < 40);
    log(site, `menu: "${a.name}" atteint en ${n} Tab, aria-expanded=${a.expanded}`);
    await page.keyboard.press('Enter'); await page.waitForTimeout(600);
    a = await active(page); log(site, `menu: après Entrée aria-expanded=${a.expanded}`);
    await page.screenshot({ path: `${OUT}/${site}_menu_ouvert.png` });
    const inside = [];
    for (let i = 0; i < 5; i++) { await page.keyboard.press('Tab'); await page.waitForTimeout(150); inside.push((await active(page)).name); }
    log(site, `menu: 5 Tab suivants -> ${inside.join(' | ')}`);
    await page.keyboard.press('Escape'); await page.waitForTimeout(400);
    a = await active(page);
    const exp = await page.evaluate(() => [...document.querySelectorAll('nav button[aria-expanded]')].map(b => b.innerText.trim().slice(0, 30) + '=' + b.getAttribute('aria-expanded')).join(', '));
    log(site, `menu: après Échap focus="${a.name}", états: ${exp}`);

    // T-form: search field, type, submit with Enter, then reach the first result
    await page.goto('https://www.service-public.gouv.fr/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/header-search-input/.test(a.tag) && n < 30);
    log(site, `recherche: champ atteint en ${n} Tab (${a.tag} "${a.name}")`);
    await page.keyboard.type('carte grise', { delay: 40 });
    await page.screenshot({ path: `${OUT}/${site}_recherche_saisie.png` });
    await Promise.all([page.waitForNavigation({ timeout: 30000 }).catch(() => {}), page.keyboard.press('Enter')]);
    await page.waitForTimeout(2500);
    log(site, `recherche: envoi par Entrée -> ${page.url()} (${await page.title()})`);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!(a.href && /vosdroits|demarches|F\d+|R\d+/.test(a.href)) && n < 80);
    log(site, `recherche: 1er résultat "${a.name}" atteint en ${n} Tab`);
    await page.screenshot({ path: `${OUT}/${site}_resultats_focus.png` });
    // dropdowns on the result page (filters), if any
    const selects = await page.evaluate(() => [...document.querySelectorAll('select')].map(s => (s.labels && s.labels[0] ? s.labels[0].innerText.trim() : s.getAttribute('aria-label') || s.id).slice(0, 40)));
    log(site, `listes déroulantes sur la page de résultats: ${JSON.stringify(selects)}`);

    // T-select on the home page (France Services or other select)
    await page.goto('https://www.service-public.gouv.fr/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/^select/.test(a.tag) && n < 120);
    if (/^select/.test(a.tag)) {
      const before = await page.evaluate(() => document.activeElement.value);
      await page.keyboard.press('ArrowDown'); await page.waitForTimeout(300);
      const after = await page.evaluate(() => document.activeElement.value);
      log(site, `liste déroulante "${a.name.slice(0, 40)}" atteinte en ${n} Tab ; flèche bas : "${before}" -> "${after}"`);
    } else log(site, `aucune liste déroulante atteinte en ${n} Tab`);

    // T-pages: follow a link with Enter and check where focus starts on the next page
    await page.goto('https://www.service-public.gouv.fr/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/Je déménage/i.test(a.name) && n < 60);
    log(site, `pages: lien "Je déménage" atteint en ${n} Tab`);
    await Promise.all([page.waitForNavigation({ timeout: 30000 }).catch(() => {}), page.keyboard.press('Enter')]);
    await page.waitForTimeout(2000);
    await page.keyboard.press('Tab'); a = await active(page);
    log(site, `pages: nouvelle page ${page.url()} ; 1er Tab -> ${a.tag} "${a.name}"`);
    await page.context().close();
  }

  // ---------- France Travail ----------
  {
    const site = 'FT';
    let page = await newPage(browser);
    await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3500);
    await page.screenshot({ path: `${OUT}/${site}_cookies.png` });
    let n = 0, a;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/Continuer sans accepter/i.test(a.name) && n < 15);
    log(site, `cookies: "Continuer sans accepter" atteint en ${n} Tab`);
    await page.keyboard.press('Enter'); await page.waitForTimeout(1000);
    a = await active(page); log(site, `cookies: focus après fermeture -> ${a.tag} "${a.name}"`);
    const stops = await tabWalk(page, site, 30);
    await page.evaluate(() => { document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0); });
    await page.waitForTimeout(300);
    await offCrops(page, site, stops);
    results[site] = { ...(results[site] || {}), stops };
    log(site, 'first stops: ' + stops.slice(0, 14).map(s => `${s.i}:${s.tag}"${s.name}"${s.expanded ? '[exp=' + s.expanded + ']' : ''}`).join(' | '));
    // menu buttons with aria-expanded among the stops
    const menuBtn = stops.find(s => s.expanded !== null && s.expanded !== undefined);
    if (menuBtn) log(site, `menu: premier bouton dépliable "${menuBtn.name}" au Tab n°${menuBtn.i}`);

    // search form
    await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3000);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/search-input/.test(a.tag) && n < 60);
    log(site, `recherche: champ ${a.tag} (nom accessible calculé ici: "${a.name}") atteint en ${n} Tab`);
    await page.keyboard.type('infirmier', { delay: 40 });
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${OUT}/${site}_recherche_saisie.png` });
    await Promise.all([page.waitForNavigation({ timeout: 30000 }).catch(() => {}), page.keyboard.press('Enter')]);
    await page.waitForTimeout(3000);
    log(site, `recherche: envoi par Entrée -> ${page.url()} (${await page.title()})`);
    // dropdowns on home: offers search block
    await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3000);
    const sel = await page.evaluate(() => [...document.querySelectorAll('select,[role=combobox]')].map(s => `${s.tagName.toLowerCase()}#${s.id} label="${(s.labels && s.labels[0] ? s.labels[0].innerText : s.getAttribute('aria-label') || '').trim().slice(0, 40)}"`));
    log(site, `listes/combobox présentes: ${JSON.stringify(sel)}`);
    n = 0;
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/^select|combobox/.test(a.tag + a.role) && n < 80);
    if (/^select|combobox/.test(a.tag + a.role)) {
      const before = await page.evaluate(() => document.activeElement.value);
      await page.keyboard.press('ArrowDown'); await page.waitForTimeout(400);
      const after = await page.evaluate(() => document.activeElement.value);
      log(site, `liste "${a.name.slice(0, 40)}" (${a.tag}) atteinte en ${n} Tab ; flèche bas : "${before}" -> "${after}"`);
      await page.screenshot({ path: `${OUT}/${site}_liste.png` });
    } else log(site, `aucune liste atteinte en ${n} Tab`);
    await page.context().close();
  }

  // ---------- FranceConnect ----------
  {
    const site = 'FC';
    let page = await newPage(browser);
    await page.goto('https://www.franceconnect.gouv.fr/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3000);
    const stops = await tabWalk(page, site, 30);
    await page.evaluate(() => { document.activeElement && document.activeElement.blur(); window.scrollTo(0, 0); });
    await page.waitForTimeout(300);
    await offCrops(page, site, stops);
    results[site] = { ...(results[site] || {}), stops };
    log(site, 'first stops: ' + stops.slice(0, 14).map(s => `${s.i}:${s.tag}"${s.name}"${s.expanded ? '[exp=' + s.expanded + ']' : ''}`).join(' | '));
    let n = 0, a;
    await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForTimeout(2500);
    do { await page.keyboard.press('Tab'); n++; a = await active(page); } while (!/^aide$|^aide /i.test(a.name) && n < 60);
    log(site, `aide/contact: lien "${a.name}" atteint en ${n} Tab`);
    await Promise.all([page.waitForNavigation({ timeout: 30000 }).catch(() => {}), page.keyboard.press('Enter')]);
    await page.waitForTimeout(2500);
    log(site, `aide: ${page.url()} (${await page.title()})`);
    const forms = await page.evaluate(() => document.querySelectorAll('form, input:not([type=hidden]), select, textarea').length);
    log(site, `aide: éléments de formulaire sur la page d'aide: ${forms}`);
    await page.keyboard.press('Tab'); a = await active(page);
    log(site, `aide: 1er Tab -> ${a.tag} "${a.name}"`);
    await page.context().close();
  }

  fs.writeFileSync(OUT + '/results.json', JSON.stringify(results, null, 1));
  await browser.close();
})();
