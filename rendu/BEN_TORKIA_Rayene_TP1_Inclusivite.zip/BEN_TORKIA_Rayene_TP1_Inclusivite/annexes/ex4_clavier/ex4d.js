const { chromium } = require('playwright');
const deep = () => { let e = document.activeElement; while (e && e.shadowRoot && e.shadowRoot.activeElement) e = e.shadowRoot.activeElement; return e; };
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'fr-FR' })).newPage();
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3500);
  await page.keyboard.press('Tab'); await page.keyboard.press('Enter'); await page.waitForTimeout(800);
  let n = 0, name = '';
  do { await page.keyboard.press('Tab'); n++; name = await page.evaluate(d => { const e = eval(d)(); return (e.getAttribute('aria-label') || e.innerText || '').trim(); }, `(${deep})`); } while (!/Services/.test(name) && n < 15);
  console.log(`Services atteint en ${n} Tab (après le bandeau)`, JSON.stringify(name));
  await page.keyboard.press('Enter'); await page.waitForTimeout(600);
  console.log('aria-expanded après Entrée:', await page.evaluate(d => eval(d)().getAttribute('aria-expanded'), `(${deep})`));
  const items = [];
  for (let i = 0; i < 6; i++) { await page.keyboard.press('Tab'); await page.waitForTimeout(150); items.push(await page.evaluate(d => { const e = eval(d)(); return (e.innerText || e.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ').slice(0, 50); }, `(${deep})`)); }
  console.log('Tab dans le sous-menu:', items.join(' | '));
  await page.screenshot({ path: __dirname + '/ex4/FT_menu_services.png' });
  await page.keyboard.press('Escape'); await page.waitForTimeout(400);
  console.log('après Échap: focus =', JSON.stringify(await page.evaluate(d => { const e = eval(d)(); return (e.innerText || e.getAttribute('aria-label') || e.tagName).trim().slice(0, 40); }, `(${deep})`)), '| menu ouvert ?', await page.evaluate(() => { const h = [...document.querySelectorAll('*')].map(x => x.shadowRoot).filter(Boolean); for (const r of [document, ...h]) { const b = r.getElementById && r.getElementById('btn-services'); if (b) return b.getAttribute('aria-expanded'); } return '?'; }));
  // where is Lyon in the suggestions?
  await page.goto('https://www.francetravail.fr/accueil/', { waitUntil: 'domcontentloaded' }); await page.waitForTimeout(3000);
  await page.locator('#autocomplete-lieu').click(); await page.keyboard.type('Lyon', { delay: 80 }); await page.waitForTimeout(2500);
  const opts = await page.evaluate(() => [...document.querySelectorAll('[role=option]')].map(o => o.innerText.trim()));
  console.log(`suggestions pour "Lyon" (${opts.length}):`, opts.join(' ; '));
  await page.screenshot({ path: __dirname + '/ex4/FT_lyon.png' });
  await browser.close();
})();
