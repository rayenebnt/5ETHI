export DISPLAY=:99
export XDG_RUNTIME_DIR=/run/user/0
export ACCESSIBILITY_ENABLED=1
export GTK_MODULES=gail:atk-bridge
export NO_AT_BRIDGE=0
export LANG=fr_FR.UTF-8
export LANGUAGE=fr
export LC_ALL=fr_FR.UTF-8
