"""Start Orca with the log-only speech server standing in for speech-dispatcher."""
import os
import runpy
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import nullspeech  # noqa: E402

sys.modules["orca.speechdispatcherfactory"] = nullspeech

# French messages live in the Ubuntu language pack, not in /usr/share/locale.
import gettext  # noqa: E402
import orca.orca_i18n as i18n  # noqa: E402
i18n.localedir = "/usr/share/locale-langpack"
gettext.bindtextdomain("orca", i18n.localedir)
sys.argv = ["orca", "--replace", f"--debug-file={os.path.join(HERE, 'orca_debug.out')}"]
runpy.run_path("/usr/bin/orca", run_name="__main__")
