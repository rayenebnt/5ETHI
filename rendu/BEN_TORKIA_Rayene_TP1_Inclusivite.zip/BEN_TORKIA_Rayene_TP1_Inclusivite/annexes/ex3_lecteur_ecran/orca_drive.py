"""Drive Chromium with the keyboard while Orca runs, and capture what Orca speaks.

Usage: python3 orca_drive.py <url> <out.json> <keyspec> [<keyspec> ...]
keyspec: "h" | "h*5" | "Tab*10" | "type:texte" | "wait:3" | "shot:name"
Each key press is sent with xdotool to the Chromium window; the SPEECH OUTPUT
lines Orca writes to its debug log after that press are recorded with it.
"""
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "orca_debug.out")
CHROME = os.environ.get("CHROME_BIN", "chromium")
SPEECH = re.compile(r"SPEECH OUTPUT: '(.*)' \{")

url, out_path, specs = sys.argv[1], sys.argv[2], sys.argv[3:]
env = dict(os.environ)


def log_size():
    return os.path.getsize(LOG)


def speech_since(pos):
    with open(LOG, "rb") as fh:
        fh.seek(pos)
        text = fh.read().decode("utf-8", "replace")
    return [m.group(1) for m in SPEECH.finditer(text)]


def xdo(*args):
    return subprocess.run(["xdotool", *args], env=env, capture_output=True, text=True).stdout.strip()


profile = os.path.join(HERE, "profile")
chrome = subprocess.Popen([
    CHROME, "--no-sandbox", "--force-renderer-accessibility", "--no-first-run",
    "--no-default-browser-check", "--disable-gpu", "--disable-features=Translate",
    f"--user-data-dir={profile}", "--window-size=1366,900", "--window-position=0,0",
    "--lang=fr-FR", "--accept-lang=fr-FR,fr", url,
], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

start = log_size()
time.sleep(14)  # page load; Orca usually starts reading the page here
win = ""
for _ in range(10):
    win = xdo("search", "--onlyvisible", "--class", "chromium").split("\n")[-1]
    if win:
        break
    time.sleep(1)
xdo("windowfocus", "--sync", win)
time.sleep(1)
steps = [{"key": "(chargement de la page)", "speech": speech_since(start)}]

for spec in specs:
    if spec.startswith("wait:"):
        time.sleep(float(spec[5:]))
        continue
    if spec.startswith("shot:"):
        subprocess.run(["import", "-window", "root", os.path.join(HERE, spec[5:] + ".png")], env=env)
        continue
    if spec.startswith("type:"):
        pos = log_size()
        xdo("type", "--delay", "80", spec[5:])
        time.sleep(1.5)
        steps.append({"key": f"(saisie « {spec[5:]} »)", "speech": speech_since(pos)})
        continue
    if "~" in spec:  # press <key> until Orca says something matching <regex>, at most <max> times
        key, regex, limit = spec.split("~")
        pat = re.compile(regex, re.I)
        for n in range(1, int(limit) + 1):
            pos = log_size()
            xdo("key", "--clearmodifiers", key)
            time.sleep(float(os.environ.get("ORCA_DELAY", "1.4")))
            said = speech_since(pos)
            steps.append({"key": key, "speech": said})
            if pat.search(" ".join(said)):
                steps.append({"key": f"(cible atteinte après {n} appuis sur {key})", "speech": []})
                break
        else:
            steps.append({"key": f"(cible NON atteinte après {limit} appuis sur {key})", "speech": []})
        continue
    key, _, times = spec.partition("*")
    for _ in range(int(times or 1)):
        pos = log_size()
        xdo("key", "--clearmodifiers", key)
        time.sleep(float(os.environ.get("ORCA_DELAY", "1.4")))
        steps.append({"key": key, "speech": speech_since(pos)})

with open(out_path, "w", encoding="utf-8") as fh:
    json.dump({"url": url, "steps": steps}, fh, ensure_ascii=False, indent=1)
for st in steps:
    print(f"[{st['key']}] " + " | ".join(st["speech"])[:400])
chrome.terminate()
time.sleep(2)
