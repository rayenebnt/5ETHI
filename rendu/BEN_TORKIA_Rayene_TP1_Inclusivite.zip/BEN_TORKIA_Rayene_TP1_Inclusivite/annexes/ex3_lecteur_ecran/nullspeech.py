"""A silent speech server for Orca: every utterance is only written to Orca's debug log."""
from orca import debug, speechserver


class SpeechServer(speechserver.SpeechServer):
    _instance = None

    @staticmethod
    def getFactoryName():
        return "Null speech (log only)"

    @staticmethod
    def getSpeechServers():
        return [SpeechServer.getSpeechServer()]

    @staticmethod
    def getSpeechServer(info=None):
        if SpeechServer._instance is None:
            SpeechServer._instance = SpeechServer()
        return SpeechServer._instance

    @staticmethod
    def shutdownActiveServers():
        pass

    def __init__(self):
        speechserver.SpeechServer.__init__(self)

    def getInfo(self):
        return ["Null speech", "null"]

    def getVoiceFamilies(self):
        return []

    def speak(self, text=None, acss=None, interrupt=True):
        pass

    def sayAll(self, utteranceIterator, progressCallback):
        for i, (context, acss) in enumerate(utteranceIterator):
            if i >= 30:
                break
            debug.printMessage(debug.LEVEL_INFO, f"SPEECH OUTPUT: '{context.utterance}' {{sayall}}", True)

    def speakCharacter(self, character, acss=None):
        pass

    def speakKeyEvent(self, event, acss=None):
        pass

    def isSpeaking(self):
        return False

    def stop(self):
        pass

    def shutdown(self):
        pass

    def reset(self, text=None, acss=None):
        pass
