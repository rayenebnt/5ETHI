#!/bin/bash
# Scenarios Orca dont les transcriptions sont dans transcriptions/ (tests du 23/11/2026).
# Prerequis : Xvfb sur :99, bus D-Bus de session, at-spi-bus-launcher, puis Orca lance par run_orca.py
#   Xvfb :99 -screen 0 1366x900x24 &
#   eval $(dbus-launch --sh-syntax) ; /usr/libexec/at-spi-bus-launcher --launch-immediately &
#   python3.12 run_orca.py &    # version de Python pour laquelle python3-gi est compile sur notre machine
. ./env.sh
SP=https://www.service-public.gouv.fr/
FT=https://www.francetravail.fr/accueil/
FC=https://www.franceconnect.gouv.fr/

# Delai par defaut entre deux touches : 1,4 s
python3 orca_drive.py $FT sc_FT0_exploration.json "Tab*6" "h*6" "m*5"
python3 orca_drive.py $SP sc_SP1a.json "k~contact~150" "shot:SP1a"
python3 orca_drive.py $SP sc_SP1b.json "Tab*4" "Return" "wait:1" "k~contact~60" "shot:SP1b"
python3 orca_drive.py $SP sc_SP2_premiere_tentative.json "e~recherch~10" "type:carte grise" "Return" "wait:5" "h*4" "shot:SP2"
python3 orca_drive.py https://www.service-public.gouv.fr/particuliers/vosdroits/R10751 sc_SP3.json "k~formulaire|pdf|t.l.charg~120" "k*2" "shot:SP3"
python3 orca_drive.py $SP sc_SP4.json "Tab~par th.me~25" "Return" "wait:1" "Tab*6" "shot:SP4"
python3 orca_drive.py $FC sc_FC1.json "k~aide|contact~60" "shot:FC1"
python3 orca_drive.py $FC sc_FC4.json "m*4" "Tab*12" "shot:FC4"

# Delai porte a 2,6 s : les annonces d'Orca arrivent avec du retard
export ORCA_DELAY=2.6
python3 orca_drive.py $SP sc_SP2c.json "Tab*8" "Insert+a" "type:carte grise" "wait:2" "Return" "wait:6" "h*3"
python3 orca_drive.py $FT sc_FT2c.json "Tab" "Return" "wait:3" "Tab*10" "Insert+a" "type:infirmier" "Tab" "type:Lyon" "wait:3" "Down*2" "Return" "Tab*3" "shot:FT2c"
python3 orca_drive.py $FT sc_FT1b.json "Tab" "Return" "wait:3" "Tab~Acc.der au contenu principal|Acc.der au pied de page|Retourner . l.accueil~14" "k~Questions et contacts~60"
