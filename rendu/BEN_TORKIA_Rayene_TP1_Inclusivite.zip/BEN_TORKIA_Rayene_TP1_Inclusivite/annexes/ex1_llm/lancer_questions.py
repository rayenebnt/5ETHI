"""Runs the Exercise 1 prompt battery against one chat-completions backend.

Each battery item is a fresh conversation (no system prompt from us); multi-turn
items send their user turns one after another, keeping the model's replies in the
history. Results are appended to a JSONL file so an interrupted run resumes.
"""
import argparse
import datetime
import json
import os
import ssl
import sys
import time
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument("--backend", choices=["pollinations", "local"], required=True)
parser.add_argument("--battery", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--max_tokens", type=int, default=1000)
parser.add_argument("--temperature", type=float, default=0.7)
parser.add_argument("--delay", type=float, default=3.0)
args = parser.parse_args()

if args.backend == "pollinations":
    URL = "https://text.pollinations.ai/openai"
    MODEL = "openai-fast"
else:
    URL = "http://127.0.0.1:8081/v1/chat/completions"
    MODEL = "local"

CTX = ssl.create_default_context()


def call(messages, seed):
    body = {
        "model": MODEL,
        "messages": messages,
        "temperature": args.temperature,
        "max_tokens": args.max_tokens,
        "seed": seed,
    }
    data = json.dumps(body).encode()
    for attempt in range(6):
        try:
            req = urllib.request.Request(URL, data=data, headers={"Content-Type": "application/json"})
            t0 = time.time()
            kwargs = {"timeout": 900}
            if URL.startswith("https"):
                kwargs["context"] = CTX
            with urllib.request.urlopen(req, **kwargs) as resp:
                payload = json.loads(resp.read())
            return payload, time.time() - t0
        except Exception as exc:  # network hiccup or rate limit: back off and retry
            wait = 15 * (attempt + 1)
            print(f"ERR {exc!r} -> retry in {wait}s", file=sys.stderr, flush=True)
            time.sleep(wait)
    raise RuntimeError("request failed 6 times")


done = set()
if os.path.exists(args.out):
    with open(args.out, encoding="utf-8") as fh:
        for line in fh:
            rec = json.loads(line)
            done.add((rec["id"], rec["sample"]))

with open(args.battery, encoding="utf-8") as fh:
    battery = json.load(fh)

with open(args.out, "a", encoding="utf-8") as out:
    for item in battery:
        for sample in range(item.get("samples", 1)):
            if (item["id"], sample) in done:
                continue
            seed = 1000 + sample
            messages, turns, last = [], [], {}
            for user_turn in item["turns"]:
                messages.append({"role": "user", "content": user_turn})
                last, latency = call(messages, seed)
                choice = last["choices"][0]
                content = choice["message"].get("content") or ""
                messages.append({"role": "assistant", "content": content})
                turns.append({
                    "user": user_turn,
                    "assistant": content,
                    "latency_s": round(latency, 1),
                    "usage": last.get("usage"),
                    "finish_reason": choice.get("finish_reason"),
                })
                time.sleep(args.delay)
            record = {
                "id": item["id"],
                "cat": item["cat"],
                "lang": item["lang"],
                "sample": sample,
                "model": last.get("model"),
                "date": datetime.datetime.now().isoformat(timespec="seconds"),
                "params": {"temperature": args.temperature, "max_tokens": args.max_tokens, "seed": seed},
                "turns": turns,
            }
            out.write(json.dumps(record, ensure_ascii=False) + "\n")
            out.flush()
            print("done", item["id"], sample, flush=True)
print("ALL DONE", flush=True)
